package com.dsy2201.evento.aplicacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventoApplicacion {
    public static void main(String[] args) {
        SpringApplication.run(EventoApplicacion.class, args);
    }
}